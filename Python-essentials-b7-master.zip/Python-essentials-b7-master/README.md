# Python-essentials-b7
This repo is for submitting the assignment of Python Essentials B7 from Letsupgrade
