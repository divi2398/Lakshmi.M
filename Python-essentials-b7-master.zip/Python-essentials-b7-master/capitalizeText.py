
def capText(string_To_Cap):
    return string_To_Cap.title()
